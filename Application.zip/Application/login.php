<?php

session_start();

$user = 'boisprivate';
$senha = '96099487';



if($_SESSION['logado'] == true){
	header('Location: index.php');
}

if(isset($_POST['user']) && isset($_POST['user'])){

	if($user == $_POST['user'] and $senha == $_POST['senha'] ){
 
//   if($user == $_POST['user2'] and $senha == $_POST['senha']){ 
	
 
	 
		$_SESSION['logado'] = true;
		header('Location: index.php');

	}else{
	
		//echo 'erro';

	}

}

?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
   
    <title> <?php echo $config['nomesite']; ?> </title>
    

    <!-- Principal CSS do Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!-- Estilos customizados para esse template -->
    <style type="text/css">
    html,
    body {
    height: 100%;
    }
    
    body {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
    align-items: center;
    padding-top: 40px;
    padding-bottom: 40px;
    background-color: #333333;
    color:#3498db;
    }
    
    .form-signin {
    width: 100%;
    max-width: 330px;
    padding: 15px;
    margin: auto;
    }
    .form-signin .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
    }
    .form-signin .form-control:focus {
    z-index: 2;
    }
    .form-signin input[type="text"] {
    margin-bottom: -1px;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
    border:2px solid #3498db;
    border-bottom-color:none;
    background:none;
    outline: 0; 
    }
    .form-signin input[type="password"] {
    margin-bottom: 10px;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    border:2px solid #3498db;
    background:none;
    outline: 0; 
    }
    .btn{
    width:50%;
    background:none;
    border:2px solid #3498db;
    color:#3498db;
    }
    textarea:focus, 
    textarea.form-control:focus, 
    input.form-control:focus, 
    input[type=text]:focus, 
    input[type=password]:focus, 
    input[type=email]:focus, 
    input[type=number]:focus, 
    input[type=button]:focus,
    [type=text].form-control:focus, 
    [type=password].form-control:focus, 
    [type=email].form-control:focus, 
    [type=tel].form-control:focus, 
    [contenteditable].form-control:focus {
    box-shadow: none;
    background:none;
    }
    .fonte{
    font-family:monospace;
    }
    </style>
  </head>
  <body class="text-center">
    <form method="post" class="form-signin">
      <img class="mb-0" src="photos/clown-hat.svg" alt="" width="75" height="75">
      <h1 class="h3 mb-3 font-weight-normal fonte">Sign in</h1>
      <label for="inputEmail" class="sr-only">Seu user</label>
      <input type="text" name="user" id="inputEmail" class="form-control" placeholder="Seu user" required autofocus>
      <label for="inputPassword" class="sr-only">Senha</label>
      <input type="password" name="senha" id="inputPassword" class="form-control" placeholder="Senha" required>
      <center><button class="btn btn-lg btn-block fonte" type="submit">Login</button></center>
      <p class="mt-5 mb-3 fonte">&copy; Copyright <?php echo date('Y'); ?> <?php echo $config['nomesite']; ?> <br>Trupe.Technology 2020 - Não possui acesso? fodase kk</p>
    </form>
  </body>
</html>
